// This is an incomplete & imprecice implementation
// It defers to the open source freebsd-elf implementations.

#ifndef ELF_H
#define ELF_H

#include <inttypes.h>

#include "freebsd-elf_common.h"
#include "freebsd-elf32.h"
#include "freebsd-elf64.h"

#endif // ELF_H
